/*
  VTL-C
  System-dependent module for AT90S8515

  T. Nakagawa

  2004/07/25
*/


#include <avr/io.h>
#include "system.h"


void initl(void) {
  WRITEW(Lmt, MEMSIZE);	/* RAM End */
  WRITEW(Bnd, Obj);	/* Program End */

  /* External RAM */
  MCUCR = _BV(SRE);

  /* UART */
  UCR = (_BV(RXEN) | _BV(TXEN));
  UBRR = 23;	/* 19200baud @ 7.3728MHz clock */

  return;
}


unsigned char getchr(void) {
  unsigned char c;

  loop_until_bit_is_clear(USR, RXC);
  c = UDR;
  putchr(c);
  return c;
}


void putchr(unsigned char c) {
  loop_until_bit_is_clear(USR, UDRE);
  UDR = c;
  return;
}
