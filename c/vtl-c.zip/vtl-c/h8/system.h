/*
  VTL-C
  System-dependent module for H8/3694F

  T. Nakagawa

  2004/06/26
*/


#ifndef _SYSTEM_H_
#define _SYSTEM_H_


#define MEMSIZE (1024 * 2 - 512)
#define READB(adrs) (*(Lct + (adrs)))
#define WRITEB(adrs, data) (*(Lct + (adrs)) = (data))
#define READW(adrs) (*(Lct + (adrs)) * 256 + *(Lct + ((adrs) + 1)))
#define WRITEW(adrs, data) (*(Lct + (adrs)) = (data) / 256, *(Lct + ((adrs) + 1)) = (data) % 256)


#define Nbf 0x82
#define Lbf 0x88
#define Svp ((2 + '!') * 2)
#define Pcc ((2 + '#') * 2)
#define Rmd ((2 + '%') * 2)
#define Bnd ((2 + '&') * 2)
#define Rnd ((2 + '\'') * 2)
#define Lmt ((2 + '*') * 2)
#define Obj 0x108


extern unsigned char Lct[];


void initl(void);
unsigned char getchr(void);
void putchr(unsigned char c);


#endif
