/*
  Console I/O
*/


#ifndef _CONIO_H_
#define _CONIO_H_


int kbhit(void);
int getch(void);
int putch(int c);


#endif
